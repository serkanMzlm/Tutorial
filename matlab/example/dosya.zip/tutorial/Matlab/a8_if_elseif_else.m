clc;
clear;
clear all;
x = 10;
y = 20;
if x>2
    y=2*x;
elseif x>9
    y=3*x;
else
    y=0;
end
%her if acıldıgında end ile kapatımalıdır.