clear;
close all;
clc;

a = "10"
b = str2num(a); % string  2 numeric    
c = num2str(b); %sayıdan karaktere cevirme

matris = [1 2 3; 4 5 6];
matris_karakter = mat2str(matris);