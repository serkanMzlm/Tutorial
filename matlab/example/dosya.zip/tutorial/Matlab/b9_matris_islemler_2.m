clear ;
clc;
close all;

zeros(3,3) %3x3 0'lardan oluşan matrs yapar ya da zeros(3)
ones(2) %2x2 1'lerden oluşur.
eye(4) %orta kısımlar 1 diger heryer 0 olan matris yapı
rand(5) % 0-1 arasında sayı olustutur
rands(5) % -1 1 arasında sayılar olusturur
x = 1:10;
diag(x) %kosegeni içine aldiği dizi olan matris oluşturur
find(x==2) %dizi içerisinde arama yapmaya yarar