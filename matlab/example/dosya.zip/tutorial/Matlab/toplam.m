function y=toplam(a,b)%y dediğimiz şey geri dondürecegi şey
y = a+b;

end