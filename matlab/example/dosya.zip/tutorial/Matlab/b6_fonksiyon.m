clc;
clear;
clear all;

sonuc= toplam(100,15)%fonksiyon cagırdık