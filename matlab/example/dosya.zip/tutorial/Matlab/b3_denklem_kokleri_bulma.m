clc;
clear;
clear all;
% x^3 - 2x + 4 denklemi yazılışı:
denklem_kokleri = [1 0 -2 4] %burda denkelmi yazmiş olduk
roots(denklem_kokleri)

