clc;
clear;
close all;

x = menu("menu","secenek1","secenek2","secenek3") %bize görsel bir arayüz sunar
%bu arayüzde ilk kelime başlık digerleri secenekler olur