clear;
close all;
clc;

d.ad="serkan";
d.soyad="mazlum";
d.yas=20;
d.uni="Marmara";
d.D_T="01.01.2000";