"""
abs () mutlak deger alma
raund () sayıları yuvarlama ikinci parametre hassasiyet
all () boş kume olup olmadigini  kontrol eder
any () icinde bir tane true deger varsa true doner
ascii()
repr()
bool()
bytes ()
list()
set()
tuple()
complex()
float()
int()
callable()
ord()
oct()
hex()
dir()
enumerate() nesnelere numaralandırma yapar
exit()
filter()
hash()
len()
map()
max()
min()
open()
pow()
print()
quit()
range()
sum() dizinin içinde ki değerleri toplamak icin
type()
zip()
vars() nesnelerin metot ve niteliklerini ogrenmek icin


"""
