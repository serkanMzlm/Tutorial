print (repr("\n")) #normalde gozukmeyen kacis satirlarini gosterilmesine yarar
print (r"\n") #repr kisaltilmis hali
print (ascii("\n")) #repr ayni
print (chr(10)) # sayilarin karsiligi gosterir
print (ord("\n")) #chr tam tersi  sayi karsiligini verir.
