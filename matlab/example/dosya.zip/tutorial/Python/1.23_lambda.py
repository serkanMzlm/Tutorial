def topla(a,b):
	return a+b
# def biraz daha kısa hali 
topla2 = lambda a,b:a+b
print (topla(2,3))
print (topla2(3,4))
