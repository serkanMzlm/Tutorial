import pyperclip as pyp
pyp.copy("merhaba") # panoya kopyalanır
pyp.paste() #yapıştırır
pyp.waitForPaste() #panoda veri varmı ona bakar yoksa bekler gelince yapıstırı
