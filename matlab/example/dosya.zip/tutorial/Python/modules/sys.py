import sys

print(sys.argv) #programa adı ve girilen parametreleri gösterir (komut satırından)
sys.executable # python calışabilir dosyasının adını gösteriri
sys.getwindowsversion() # kullanılan windows hakkında bilgi verir
sys.platform #kodların calıştıgı işletim sistemi hakkında bilgi verir
sys.version #python sürümünün versiyonunu verir

sys.exit() #programı sonlanrırır zorla kapatır
