import math

math.ceil(19.23) #üste yuvarlar
math.floor(19.23) #alta yuvarlar
math.copysign(15,-1) #ikinci sayinin işaretini birincisine verir
math.fabs(-15) #mutlak deger alma
math.factorial(5) #faktöriyel alır
math.fmod(15,2) #kalan verir
math.gcd(12,22) #EBOB iki sayi
math.e #euler sabiti tutulur 2.7...
math.pi # pi sabiti tutulur
math.tau #tau sabiti tutulur  pi*2 = tau
math.exp(2) #e**2
math.log(25,5)
math.log1p(0) # e tabanına göre log alır
math.pow(10,2) #kuvvet alma
math.sqrt(10) #kök alma
math.degrees(1.5) #radyana --> derece
math.radians(90) #derece --> radyan


